export class AppConfig {
    public appTitle: string = "ThingBook";
    public languageCode: string = "en";
    public languageName: string = "English";
    public apiBase: string = "http://localhost:";
    public buildVersion: string = "(Build: 0.0.1-4.6.2018-5.13)";//""
}