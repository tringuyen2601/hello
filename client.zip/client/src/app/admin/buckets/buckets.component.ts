import { Component, OnInit,Injectable, Input, Output,  EventEmitter } from '@angular/core';
import { AdminBucketService} from '../../services/admin.bucket.service';
import { Ng2SmartTableModule,LocalDataSource } from 'ng2-smart-table';
import { ManageBucketsConfig } from '../admin.config';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogService } from "../../confirmation-dialog/confirmation-dialog.service";
import { FormGroup, FormBuilder, Validators,FormControl } from '@angular/forms';
import { AuthService } from "../../services/auth.service";
@Injectable()
@Component({
  selector: 'buckets-admin',
  templateUrl: './buckets.component.html',
  styleUrls: ['./buckets.component.css'],
  providers: []
})
export class BucketsComponent implements OnInit {

  constructor(private adminBucketService: AdminBucketService,
              private toastrService: ToastrService,
              private confirmationDialogService: ConfirmationDialogService,
              private authService: AuthService) {}
  @Input() data: any[] = [];
  @Output() onDelete = new EventEmitter<boolean>();
  @Output() onCreate = new EventEmitter<any>();
  @Output() onEdit = new EventEmitter<boolean>();

  public settings: any = ManageBucketsConfig.ManageBucketSettings;
   
  ngOnInit() {
  }
  
  //get all buckets of company
  public getAllBucketsOfCompany(companyId){
    this.adminBucketService.getBucketsOfCompanyService(companyId).subscribe(data =>{
      this.data = data.data;
    }, err => {
      this.toastrService.error(err.error.message, 'Error');
    });
  }

  //create bucket
  public onCreateConfirm(event) {
    this.confirmationDialogService.confirm('Confirm', 'Bucket Create?', 'Yes', 'No').then(result=>{
      if(result){
        console.log('True: ', result);
        let name:string = event.newData['name'];
        console.log('Name: ', name);
        this.adminBucketService.addBucketToCompanyService(this.authService.getSelectedCompanyId(), name).subscribe(data => {
          this.toastrService.success(data.message, 'Success');
          this.adminBucketService.getBucketsOfCompanyService(this.authService.getSelectedCompanyId()).subscribe(data =>{
          this.data = data.data;
          //send notification
          this.onCreate.emit(this.data);
          event.confirm.resolve(event.newData);
          }, err => {
            this.toastrService.error(err.error.message, 'Error');
          });
        }, err => {
          this.toastrService.error(err.error.message, 'Error');
          event.confirm.reject();
        });
      } else {
        console.log('False: ', result);
        event.confirm.reject();
      }
    });
  }

  //delete bucket
  public onDeleteBucket(event){
    console.log('onDeleteBucket Inside', event);
    this.confirmationDialogService.confirm('Confirm', 'Bucket Delete?', 'Yes', 'No').then(result=>{
      if(result){
        let bucketId:string = event.data.id;
        this.adminBucketService.deleteBucketOfCompanyService(this.authService.getSelectedCompanyId(), bucketId).subscribe(data => {
          this.toastrService.success(data.data, 'Success');
          //send notification
          this.onDelete.emit(true);
          event.confirm.resolve(event.newData);
        }, err => {
          this.toastrService.error(err.error.message, 'Error');
          event.confirm.reject();
        });
      } else {
        event.confirm.reject();
      }
    });

  }

  //edit bucket
  public onEditBucket(event){
    this.confirmationDialogService.confirm('Confirm', 'Bucket Edit?', 'Yes', 'No').then(result=>{
      if(result){
        let bucketId:string = event.data.id;
        let newName: string = event.newData['name'];
        this.adminBucketService.editBucketOfCompanyService(this.authService.getSelectedCompanyId(), bucketId, newName).subscribe(data => {
          //this.getAllBucketsOfCompany(this.authService.getSelectedCompanyId());
          this.toastrService.success(data.message, 'Success');
          //send notification
          this.onEdit.emit(true);
          event.confirm.resolve(event.newData);
        }, err => {
          this.toastrService.error(err.error.message, err);
          event.confirm.reject();
        });
      } else {
        event.confirm.reject();
      }
    });
  }
}
