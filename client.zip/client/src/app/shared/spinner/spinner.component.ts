import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'spinner-loading',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.css'],
  
})
export class SpinnerComponent implements OnInit {
  constructor(){}

  ngOnInit() {

  }
}
